package com.sketchbot.app

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private var bitmap: Bitmap? = null
    private var loaded: Tracer.Loaded? = null
    private var threshold = 55
    private var detail = 40
    private var brushPx = 3
    private var colors = 24
    private var fillMode = false
    private var soft = 0
    private var blend = false
    private lateinit var sfLabel: TextView
    private lateinit var preview: ImageView
    private lateinit var status: TextView
    private lateinit var thLabel: TextView
    private lateinit var dtLabel: TextView
    private lateinit var fgLabel: TextView
    private lateinit var clLabel: TextView

    private fun label() = TextView(this).apply { gravity = Gravity.CENTER }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density

        val info = TextView(this).apply {
            text = "1) فعّل الخدمة\n2) اختر الصورة وراجع المعاينة\n" +
                "3) في Sketchbook كبّر الكانفس ليملأ مكان الرسم الشاشة، واختر أرق فرشاة\n" +
                "4) من الشريط العائم: ⛶ ثم اضغط زاويتين تحيطان بمكان الرسم\n" +
                "5) 🎨 لتعليم اللون، 🪣 لتعليم أداة Fill، ✏ لتعليم الفرشاة (مرة واحدة)\n" +
                "6) اختر الفرشاة الرفيعة ثم اضغط ▶ ابدأ وانتظر"
            textSize = 15f
            gravity = Gravity.CENTER
        }
        val btnAcc = Button(this).apply { text = "تفعيل الخدمة" }
        val btnPick = Button(this).apply { text = "اختيار صورة" }
        val btnLayers = Button(this).apply { text = "الطبقات: طبقة لكل لون (اضغط للتبديل)" }
        val btnMode = Button(this).apply { text = "التلوين: فرشاة دقيقة (اضغط للتبديل)" }

        thLabel = label().apply { text = "سواد الخطوط: $threshold" }
        val seekTh = SeekBar(this).apply { max = 120; progress = threshold - 20 }
        dtLabel = label().apply { text = "تفاصيل الخطوط: $detail" }
        val seekDt = SeekBar(this).apply { max = 100; progress = detail }
        clLabel = label().apply { text = "عدد الألوان: $colors (0 = بدون تلوين)" }
        sfLabel = label().apply { text = "نعومة حواف الألوان: $soft (0 حادة، 10 ممتزجة؛ مع فرشاة ناعمة الحواف)" }
        val seekSf = SeekBar(this).apply { max = 10; progress = soft }
        val btnBlend = Button(this).apply { text = "تنعيم الحدود بأداة Smudge: معطّل (اضغط للتبديل)" }
        val seekCl = SeekBar(this).apply { max = 40; progress = colors }
        fgLabel = label().apply { text = "سمك الفرشاة: $brushPx (اختر أرق فرشاة في Sketchbook، وكلما قلّ الرقم زادت الدقة والوقت)" }
        val seekFg = SeekBar(this).apply { max = 19; progress = brushPx - 1 }

        preview = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.WHITE)
        }
        status = label().apply { text = "لم تُختر صورة بعد" }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((16 * d).toInt(), (24 * d).toInt(), (16 * d).toInt(), (16 * d).toInt())
            addView(info)
            addView(btnAcc)
            addView(btnPick)
            addView(btnMode)
            addView(btnLayers)
            addView(thLabel); addView(seekTh)
            addView(dtLabel); addView(seekDt)
            addView(clLabel); addView(seekCl)
            addView(fgLabel); addView(seekFg)
            addView(preview, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, (420 * d).toInt()))
            addView(status)
        }
        setContentView(ScrollView(this).apply { addView(root) })

        btnAcc.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btnPick.setOnClickListener {
            val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
            startActivityForResult(Intent.createChooser(i, "اختر صورة"), 1)
        }

        btnBlend.setOnClickListener {
            blend = !blend
            btnBlend.text = if (blend) "تنعيم الحدود بأداة Smudge: مفعّل (علّم 👆، وطبقة واحدة)" else "تنعيم الحدود بأداة Smudge: معطّل (اضغط للتبديل)"
            process()
        }
        btnLayers.setOnClickListener {
            Shared.layers = !Shared.layers
            btnLayers.text = if (Shared.layers) "الطبقات: طبقة لكل لون (اضغط للتبديل)" else "الطبقات: طبقة واحدة (اضغط للتبديل)"
        }
        btnMode.setOnClickListener {
            fillMode = !fillMode
            btnMode.text = if (fillMode) "التلوين: تعبئة Fill (اضغط للتبديل)" else "التلوين: فرشاة دقيقة (اضغط للتبديل)"
            process()
        }

        fun bind(seek: SeekBar, onChange: (Int) -> Unit) {
            seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { onChange(p) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { process() }
            })
        }
        bind(seekTh) { p -> threshold = 20 + p; thLabel.text = "سواد الخطوط: $threshold" }
        bind(seekDt) { p -> detail = p; dtLabel.text = "تفاصيل الخطوط: $detail" }
        bind(seekSf) { p -> soft = p; sfLabel.text = "نعومة حواف الألوان: $soft (0 حادة، 10 ممتزجة؛ مع فرشاة ناعمة الحواف)" }
        bind(seekCl) { p -> colors = p; clLabel.text = "عدد الألوان: $colors (0 = بدون تلوين)" }
        bind(seekFg) { p -> getSharedPreferences("sb", MODE_PRIVATE).edit().remove("brushScreen").apply(); brushPx = 1 + p; fgLabel.text = "سمك الفرشاة: $brushPx (اختر أرق فرشاة في Sketchbook، وكلما قلّ الرقم زادت الدقة والوقت)" }
    }

    override fun onResume() {
        super.onResume()
        if (bitmap != null) process()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            status.text = "جاري تحميل الصورة..."
            thread {
                val ld = Tracer.load(this, uri, 1100)
                runOnUiThread {
                    if (ld == null) {
                        status.text = "تعذّر فتح الصورة"
                    } else {
                        bitmap = ld.bmp
                        loaded = ld
                        process()
                    }
                }
            }
        }
    }

    // كم بكسل على الشاشة يساوي بكسل واحد من الصورة المحلَّلة (حسب منطقة الرسم المحفوظة)
    private fun screenScale(bmp: Bitmap): Float {
        val p = getSharedPreferences("sb", MODE_PRIVATE)
        var rw = resources.displayMetrics.widthPixels * 0.9f
        var rh = resources.displayMetrics.heightPixels * 0.7f
        if (p.contains("l")) {
            rw = p.getFloat("r", 0f) - p.getFloat("l", 0f)
            rh = p.getFloat("b", 0f) - p.getFloat("t", 0f)
        }
        val s = Math.min(rw / bmp.width, rh / bmp.height)
        return Math.max(0.05f, s)
    }

    private fun process() {
        val bmp = bitmap ?: return
        val ld = loaded ?: return
        status.text = "جاري تحليل الصورة..."
        val t = threshold
        val dt = detail
        val sc = screenScale(bmp)
        val measured = getSharedPreferences("sb", MODE_PRIVATE).getFloat("brushScreen", 0f)
        val eff = if (measured > 0f) measured else brushPx.toFloat()
        val fg = Math.max(1, Math.round(eff * 0.8f / sc))
        val cl = colors
        val fm = fillMode
        val sf = soft
        val bl = blend
        thread {
            try {
                val r = Tracer.process(bmp, t, dt, fg, cl, fm, sf, bl)
                runOnUiThread {
                    Shared.phases = r.phases
                    Shared.imgW = r.w
                    Shared.imgH = r.h
                    Shared.fx0 = ld.fx0
                    Shared.fy0 = ld.fy0
                    Shared.fw = ld.fw
                    Shared.fh = ld.fh
                    Shared.aspect = ld.aspect
                    preview.setImageBitmap(r.preview)
                    var total = 0
                    for (p in r.phases) total += p.strokes.size
                    val want = r.lineThick * sc
                    val mb = getSharedPreferences("sb", MODE_PRIVATE).getFloat("brushScreen", 0f)
                    val rec = if (want > 0f) {
                        " | سمك الخطوط الأصلي ≈ ${"%.1f".format(want)} بكسل" +
                            (if (mb > 0f) " | فرشاتك المقاسة = ${mb.toInt()} بكسل" +
                                (if (mb > want * 1.4f) ": كبيرة، صغّر Size إلى ${"%.0f".format(100f * want / mb)}% تقريباً" else ": مناسبة")
                            else " | قِس فرشاتك بزر 📏")
                    } else ""
                    status.text = "جاهز: ${r.phases.size} مرحلة، $total خط$rec"
                }
            } catch (e: Throwable) {
                runOnUiThread { status.text = "خطأ في التحليل: ${e.message}" }
            }
        }
    }
}
